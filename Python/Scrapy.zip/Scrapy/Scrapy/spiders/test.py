# -*- coding: utf-8 -*-
import re
import scrapy
from urllib import parse
from scrapy.http import Request
from Scrapy.items import demo


class TestSpider(scrapy.Spider):
    name = 'test'
    #allowed_domains = ['blog.jobbole.com']
    start_urls = ['http://blog.jobbole.com/all-posts/']


    def parse(self, response):
        post_nodes = response.css('#archive .floated-thumb .post-thumb a')
        for post_node in post_nodes:
            image_url = post_node.css('img::attr(src)').extract_first('')
            post_url = post_node.css('::attr(href)').extract_first('')
            yield Request(
                url=parse.urljoin(response.url, post_url),
                meta={'front_image_url': image_url},
                callback=self.parse_detail
            )
        next_url = response.css('.next.page-numbers::attr(href)').extract_first(
            '')
        if next_url:
            yield Request(
                url=parse.urljoin(response.url, next_url),
                callback=self.parse
            )






    def parse_detail(self, response):
        title = response.css('.entry-header h1::text').extract_first('')
        print(title)

        data = response.css('.entry-meta-hide-on-mobile::text').extract_first(
            '').strip().replace(' .', '')
        print(data)

        tag_list = response.css(
            '.entry-meta-hide-on-mobile a::text').extract_first('')
        print(tag_list)

        pra_num = response.css('.vote-post-up h10::text').extract_first(
            '')  # 提取点赞数
        match_re = re.match('.*?(\d+).*?', pra_num)
        if match_re:
            pra_num = int(match_re.group(1))  # 如果存在取第一个括号里边的
        else:
            pra_num = 0
        print(pra_num)

        fav_num = response.css('.bookmark-btn i::text').extract_first('')
        # 提取收藏数
        match_re = re.match('.*?(\d+).*?',fav_num)
        #正则化表达式     其中：(\d+)为匹配的内容，+为匹配多少次

        if match_re:
            fav_num = int(match_re.group(1))  # 如果存在取第一个括号里边的
        else:
            fav_num = 0
        print(fav_num)
        content = response.css('.entry p::text').extract()
        print(content)
        front_image_url = response.meta.get('front_image_url', '')
        article_Item = demo()
        print(front_image_url)
        article_Item["title"] = title
        article_Item["data"] = data
        article_Item["tag_list"] = tag_list
        #article_Item["pra_num"] = pra_num
        #article_Item["fav_num"] = fav_num
        #article_Item["match_re"] = match_re
        article_Item["content"] = content
        article_Item["front_image_url"] = [front_image_url]

        yield article_Item
