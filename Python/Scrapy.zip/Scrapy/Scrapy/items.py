# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


# class ScrapyItem(scrapy.Item):
#     # define the fields for your item here like:
#     # name = scrapy.Field()
#     pass
class demo(scrapy.Item):
    title = scrapy.Field()
    data = scrapy.Field()
    tag_list = scrapy.Field()
   # pra_num = scrapy.Field()
   # fav_num = scrapy.Field()
    #match_re = scrapy.Field()
    front_image_url = scrapy.Field()
    content = scrapy.Field()

